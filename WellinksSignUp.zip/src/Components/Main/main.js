import React from "react";
import "./main.css";
import HorizontalLinearStepper from "../UIComponents/HorizontalLinearStepper";
import AddContactInfo from "./AddContactInfo"

function Main() {
    const steps = [
        {step:'Is Wellinks in your plan?', text:'First, let’s find out if we partner with your health insurance.'},
        {step:'Add your contact info', text:'Tell us where to send your Welcome Kit.'},
        {step:'Secure your account', text:'Almost done! Add an email and a password.'},
        {step:'Set up your first session', text:'Pick a day and time for a 45-minute session with your Health Coach.'},
        {step:'Congratulations', text:'You are all set up.'}
      ]; 
  return (
    <div>
      <div class="section-hero-about wf-section">
        <img
          src="https://uploads-ssl.webflow.com/614a1ca9934d3f7e2d47575f/614a1ca9934d3f40d7475804_Dec%20(3).svg"
          loading="eager"
          alt=""
          className="bg-absolute-about"
        />
        <div className="container">
          <div
           
            className="about-hero-wrap"
          >
            <div className="subhead-small blue-color-text">ENROLLMENT</div>
            <h1 class="h1-hero black-color-text">
              Is Wellinks in your plan?
            </h1>
            <p class="subtext-home large black-color-text text-opacity-80">First, let’s find out if we partner with your health insurance.</p>
          </div>
          <div style={{marginBottom:'50px'}}>
          <HorizontalLinearStepper />
          </div>
             
          <div className="form_onboarding">
           <AddContactInfo />
          </div>
        </div>
      </div>     
    </div>
  );
}

export default Main;
