import * as React from "react";
import Box from "@mui/material/Box";
import helpImage from "../../Images/Help.svg";

export default function AddContactInfo() {
  return (
    <>
      <div className="form_onboarding_frame">
        <div className="form_onboarding_frame_header">
          <div className="form_onboarding_frame_header_title">
            Member Information
          </div>
          <div className="form_onboarding_helpcontrol">
            <div className="form_onboarding_help_image">
              <img src="http://localhost:3000/help.svg" alt="" />
            </div>
            <div className="form_onboarding_frame_help_text">Help</div>
          </div>
        </div>
        <div className="form_onboarding_frame_header_description">
          Enter the information as it is on your insurance card(s) to see if
          your plan is eligible.
        </div>
      </div>
      <div className="form_onboarding_form_controlgroup">
        <div className="basefield_title">
          <div className="base_field_text">Insurer</div>
        </div>
        <div className="base_fieldbox">
            <div className="base_field_container">
                <div className="base_field_container_text">
                <select >
                    <option> Highmark BlueCross Blue shield</option>
                </select>
                </div>
            </div>
        </div>
      </div>
    </>
  );
}
