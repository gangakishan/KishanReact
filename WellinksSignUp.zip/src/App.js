import './App.css';
import NewHeader from './NewHeader';
import Main from './Components/Main/main';

function App() {
  return (
    <div className="App">
      <NewHeader/>
      <Main/>
    </div>
  );
}

export default App;
